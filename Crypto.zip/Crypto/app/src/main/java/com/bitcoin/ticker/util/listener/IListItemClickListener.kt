package com.bitcoin.ticker.util.listener

import com.bitcoin.ticker.data.model.asset.PayloadX

interface IListItemClickListener {
    fun setOnClickItemListener(id: String)
}