package com.bitcoin.ticker.data.model.detail

data class PayLoadDetail(
    val payload: Payload
)