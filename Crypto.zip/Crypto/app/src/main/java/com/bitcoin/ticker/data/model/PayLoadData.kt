package com.bitcoin.ticker.data.model

data class PayLoadData(val payload: Payload)