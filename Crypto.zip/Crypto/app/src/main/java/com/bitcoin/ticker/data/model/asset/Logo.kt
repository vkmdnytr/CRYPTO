package com.bitcoin.ticker.data.model.asset

data class Logo(
    val imageData: String?,
    val mimeType: String?
)