package com.bitcoin.ticker.data.model.detail

data class Logo(
    val imageData: String,
    val mimeType: String
)