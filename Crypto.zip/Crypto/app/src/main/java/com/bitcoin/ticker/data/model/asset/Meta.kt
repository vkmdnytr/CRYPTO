package com.bitcoin.ticker.data.model.asset

data class Meta(
    val index: Int,
    val limit: Int,
    val results: Int,
    val totalCount: Int
)