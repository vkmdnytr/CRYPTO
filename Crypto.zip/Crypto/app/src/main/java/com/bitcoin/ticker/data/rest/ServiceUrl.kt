package com.bitcoin.ticker.data.rest

object ServiceUrls{
    const val APIKEY="69c7dbddac4dd080c9c462cb239bfdd77469ea75"
    const val BASE_URL = "https://api.cryptoapis.io/v1/"
    const val ASSETS_URL="assets"
    const val ASSETS_DETAIL_URL="assets/{assetId}"
 }