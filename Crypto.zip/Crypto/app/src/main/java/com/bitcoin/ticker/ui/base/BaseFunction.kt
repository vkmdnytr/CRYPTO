package com.bitcoin.ticker.ui.base

interface BaseFunction {
     fun showProgress()
     fun showView()
}